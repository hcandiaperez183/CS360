package com.example.eventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;

/**
 * Login screen. Checks the username and password against the users table,
 * or creates a new account for a first-time user.
 */
public class LoginActivity extends AppCompatActivity {

    /** Intent extra that carries the logged-in user's ID to the other screens. */
    public static final String EXTRA_USER_ID = "user_id";

    private static final int MIN_PASSWORD_LENGTH = 6;

    private TextInputLayout usernameLayout;
    private TextInputLayout passwordLayout;
    private EditText usernameField;
    private EditText passwordField;
    private UserDao userDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameLayout = findViewById(R.id.layoutUsername);
        passwordLayout = findViewById(R.id.layoutPassword);
        usernameField = findViewById(R.id.editUsername);
        passwordField = findViewById(R.id.editPassword);
        userDao = new UserDao(this);

        findViewById(R.id.buttonLogin).setOnClickListener(v -> attemptLogin());
        findViewById(R.id.buttonCreateAccount).setOnClickListener(v -> attemptCreateAccount());
    }

    /** Logs in if the username and password match a saved account. */
    private void attemptLogin() {
        if (!isInputValid(false)) {
            return;
        }
        long userId = userDao.checkLogin(getUsername(), getPassword());
        if (userId == UserDao.NO_USER) {
            passwordLayout.setError(getString(R.string.error_login_failed));
            return;
        }
        openEventList(userId);
    }

    /** Saves a new account to the database, then logs the user in. */
    private void attemptCreateAccount() {
        if (!isInputValid(true)) {
            return;
        }
        long userId = userDao.createUser(getUsername(), getPassword());
        if (userId == UserDao.NO_USER) {
            usernameLayout.setError(getString(R.string.error_username_taken));
            return;
        }
        Toast.makeText(this, R.string.account_created, Toast.LENGTH_SHORT).show();
        openEventList(userId);
    }

    /** Shows an error under any empty field. New accounts also need a longer password. */
    private boolean isInputValid(boolean isNewAccount) {
        usernameLayout.setError(null);
        passwordLayout.setError(null);
        boolean valid = true;

        if (getUsername().isEmpty()) {
            usernameLayout.setError(getString(R.string.error_username_required));
            valid = false;
        }
        if (getPassword().isEmpty()) {
            passwordLayout.setError(getString(R.string.error_password_required));
            valid = false;
        } else if (isNewAccount && getPassword().length() < MIN_PASSWORD_LENGTH) {
            passwordLayout.setError(getString(R.string.error_password_too_short));
            valid = false;
        }
        return valid;
    }

    private String getUsername() {
        return FormUtils.textOf(usernameField);
    }

    private String getPassword() {
        return FormUtils.textOf(passwordField);
    }

    /** Opens the event grid for this user and closes the login screen. */
    private void openEventList(long userId) {
        Intent intent = new Intent(this, EventListActivity.class);
        intent.putExtra(EXTRA_USER_ID, userId);
        startActivity(intent);
        finish(); // So pressing Back on the event list doesn't return to login.
    }
}
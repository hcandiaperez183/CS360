package com.example.eventtracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Creates and opens the app's SQLite database. It holds two tables:
 * users (login accounts) and events (each user's events).
 * Only one instance is shared across the app.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "event_tracker.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "_id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD_HASH = "password_hash";
    public static final String COL_SALT = "salt";
    public static final String COL_PHONE = "phone";

    // Events table
    public static final String TABLE_EVENTS = "events";
    public static final String COL_EVENT_ID = "_id";
    public static final String COL_EVENT_USER_ID = "user_id";
    public static final String COL_EVENT_NAME = "name";
    public static final String COL_EVENT_DATE = "date";
    public static final String COL_EVENT_TIME = "time";
    public static final String COL_EVENT_DESCRIPTION = "description";
    public static final String COL_REMINDER_SENT = "reminder_sent";

    private static DatabaseHelper instance;

    /** Returns the single shared helper so the database isn't opened twice. */
    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        // Needed so deleting a user also deletes their events (ON DELETE CASCADE).
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Usernames are unique and not case-sensitive ("Sam" and "sam" are the same user).
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE COLLATE NOCASE, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL, "
                + COL_SALT + " TEXT NOT NULL, "
                + COL_PHONE + " TEXT)");

        // reminder_sent is 0 or 1 so each event is only texted about once.
        db.execSQL("CREATE TABLE " + TABLE_EVENTS + " ("
                + COL_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_EVENT_USER_ID + " INTEGER NOT NULL, "
                + COL_EVENT_NAME + " TEXT NOT NULL, "
                + COL_EVENT_DATE + " TEXT NOT NULL, "
                + COL_EVENT_TIME + " TEXT NOT NULL, "
                + COL_EVENT_DESCRIPTION + " TEXT, "
                + COL_REMINDER_SENT + " INTEGER NOT NULL DEFAULT 0, "
                + "FOREIGN KEY (" + COL_EVENT_USER_ID + ") REFERENCES "
                + TABLE_USERS + "(" + COL_USER_ID + ") ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 is the only version so far. A real update would migrate data here.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }
}
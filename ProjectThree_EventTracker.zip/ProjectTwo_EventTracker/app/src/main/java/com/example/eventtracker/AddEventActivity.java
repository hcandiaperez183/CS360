package com.example.eventtracker;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Add / edit event screen. Opened without an event ID it creates a new event;
 * opened with one, it loads that event and saves changes to it.
 */
public class AddEventActivity extends AppCompatActivity {

    public static final String EXTRA_EVENT_ID = "event_id";

    private static final long NEW_EVENT = -1;

    private EditText nameField;
    private EditText dateField;
    private EditText timeField;
    private EditText descriptionField;
    private EventDao eventDao;
    private long userId;
    private long eventId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        nameField = findViewById(R.id.editEventName);
        dateField = findViewById(R.id.editEventDate);
        timeField = findViewById(R.id.editEventTime);
        descriptionField = findViewById(R.id.editEventDescription);
        eventDao = new EventDao(this);

        userId = getIntent().getLongExtra(LoginActivity.EXTRA_USER_ID, UserDao.NO_USER);
        eventId = getIntent().getLongExtra(EXTRA_EVENT_ID, NEW_EVENT);
        if (eventId != NEW_EVENT) {
            loadExistingEvent();
        }

        findViewById(R.id.buttonSave).setOnClickListener(v -> saveEvent());
        // Cancel goes back to the event list without changing anything.
        findViewById(R.id.buttonCancel).setOnClickListener(v -> finish());
    }

    /** Fills the form with the saved event and switches the title to "Edit event". */
    private void loadExistingEvent() {
        Event event = eventDao.getEvent(eventId);
        if (event == null) {
            eventId = NEW_EVENT; // It was deleted, so treat this as a new event.
            return;
        }
        TextView titleText = findViewById(R.id.textFormTitle);
        titleText.setText(R.string.title_edit_event);
        nameField.setText(event.getName());
        dateField.setText(event.getDate());
        timeField.setText(event.getTime());
        descriptionField.setText(event.getDescription());
    }

    /** Checks the form, then inserts a new event or updates the existing one. */
    private void saveEvent() {
        String name = FormUtils.textOf(nameField);
        String date = FormUtils.textOf(dateField);
        String time = FormUtils.textOf(timeField);
        if (time.isEmpty()) {
            time = getString(R.string.time_all_day);
        }
        if (!isFormValid(name, date, time)) {
            return;
        }

        Event event = new Event(eventId, name, date, time, FormUtils.textOf(descriptionField));
        if (eventId == NEW_EVENT) {
            eventDao.addEvent(userId, event);
        } else {
            eventDao.updateEvent(event);
        }
        Toast.makeText(this, R.string.event_saved, Toast.LENGTH_SHORT).show();
        finish();
    }

    /** Puts an error on each field that is missing or in the wrong format. */
    private boolean isFormValid(String name, String date, String time) {
        boolean valid = true;
        if (name.isEmpty()) {
            nameField.setError(getString(R.string.error_event_name_required));
            valid = false;
        }
        if (Event.parseDate(date) == null) {
            dateField.setError(getString(R.string.error_event_date_invalid));
            valid = false;
        }
        boolean isAllDay = time.equalsIgnoreCase(getString(R.string.time_all_day));
        if (!isAllDay && Event.parseTime(time) == null) {
            timeField.setError(getString(R.string.error_event_time_invalid));
            valid = false;
        }
        return valid;
    }
}
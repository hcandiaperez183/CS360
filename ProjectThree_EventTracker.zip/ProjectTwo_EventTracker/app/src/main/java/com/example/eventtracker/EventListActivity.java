package com.example.eventtracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

/**
 * Event list screen. Shows the logged-in user's events from the database
 * as a grid, and links to the add/edit and SMS screens.
 */
public class EventListActivity extends AppCompatActivity
        implements EventAdapter.OnEventActionListener {

    private long userId;
    private EventDao eventDao;
    private EventAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);

        userId = getIntent().getLongExtra(LoginActivity.EXTRA_USER_ID, UserDao.NO_USER);
        if (userId == UserDao.NO_USER) {
            // Nobody is logged in, so go back to the login screen.
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }
        eventDao = new EventDao(this);

        adapter = new EventAdapter(this);
        RecyclerView recyclerView = findViewById(R.id.recyclerEvents);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        findViewById(R.id.buttonAddEvent).setOnClickListener(v ->
                startActivity(screenIntent(AddEventActivity.class)));
        findViewById(R.id.buttonSms).setOnClickListener(v ->
                startActivity(screenIntent(SmsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Runs on first load and every time the user comes back from another screen.
        refreshEvents();
        int remindersSent = SmsReminderSender.sendDueReminders(this, userId);
        if (remindersSent > 0) {
            Toast.makeText(this, getString(R.string.reminders_sent, remindersSent),
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onEditEvent(Event event) {
        Intent intent = screenIntent(AddEventActivity.class);
        intent.putExtra(AddEventActivity.EXTRA_EVENT_ID, event.getId());
        startActivity(intent);
    }

    @Override
    public void onDeleteEvent(Event event) {
        // Confirm first, because a deleted event can't be recovered.
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.delete_dialog_title)
                .setMessage(getString(R.string.delete_dialog_message, event.getName()))
                .setNegativeButton(R.string.button_cancel, null)
                .setPositiveButton(R.string.button_delete, (dialog, which) -> {
                    eventDao.deleteEvent(event.getId());
                    refreshEvents();
                })
                .show();
    }

    /** Reloads the grid from the database. */
    private void refreshEvents() {
        adapter.setEvents(eventDao.getEventsForUser(userId));
    }

    /** Builds an intent for another screen that carries the logged-in user's ID. */
    private Intent screenIntent(Class<?> screen) {
        Intent intent = new Intent(this, screen);
        intent.putExtra(LoginActivity.EXTRA_USER_ID, userId);
        return intent;
    }
}
package com.example.eventtracker;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Locale;

/** One event from the events table, shown as a row in the grid. */
public class Event {

    // Date format the user types, e.g. "10/25/2026". STRICT rejects dates like 02/30/2026.
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter
            .ofPattern("M/d/uuuu", Locale.US)
            .withResolverStyle(ResolverStyle.STRICT);

    // Time format the user types, e.g. "6:30 PM" (upper or lower case).
    private static final DateTimeFormatter TIME_FORMAT = new DateTimeFormatterBuilder()
            .parseCaseInsensitive()
            .appendPattern("h:mm a")
            .toFormatter(Locale.US);

    private final long id;
    private final String name;
    private final String date;
    private final String time;
    private final String description;

    public Event(long id, String name, String date, String time, String description) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.time = time;
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getDescription() {
        return description;
    }

    /**
     * When the event starts, or null if the date can't be read.
     * All-day events (no readable time) count as starting at midnight.
     */
    public LocalDateTime getStartDateTime() {
        LocalDate day = parseDate(date);
        if (day == null) {
            return null;
        }
        LocalTime startTime = parseTime(time);
        return day.atTime(startTime != null ? startTime : LocalTime.MIDNIGHT);
    }

    /** Reads text like "10/25/2026". Returns null if it isn't a real date. */
    public static LocalDate parseDate(String text) {
        try {
            return text == null ? null : LocalDate.parse(text.trim(), DATE_FORMAT);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    /** Reads text like "6:30 PM". Returns null if it isn't a valid time. */
    public static LocalTime parseTime(String text) {
        try {
            return text == null ? null : LocalTime.parse(text.trim(), TIME_FORMAT);
        } catch (DateTimeParseException e) {
            return null;
        }
    }
}
package com.example.eventtracker;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.content.ContextCompat;

import java.time.Duration;
import java.time.LocalDateTime;

/**
 * Texts the user about events that start within the next 24 hours.
 * Does nothing if SMS permission was denied or no phone number is saved,
 * so the rest of the app works the same either way.
 */
public final class SmsReminderSender {

    private static final String TAG = "SmsReminderSender";
    private static final Duration REMINDER_WINDOW = Duration.ofHours(24);

    private SmsReminderSender() {
        // Utility class: no instances.
    }

    /** True if the user has allowed the app to send SMS messages. */
    public static boolean hasSmsPermission(Context context) {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    /** Sends any reminders that are due and returns how many were sent. */
    public static int sendDueReminders(Context context, long userId) {
        if (!hasSmsPermission(context)) {
            return 0; // Permission denied: skip SMS, everything else keeps working.
        }
        String phoneNumber = new UserDao(context).getPhoneNumber(userId);
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            return 0;
        }

        EventDao eventDao = new EventDao(context);
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime cutoff = now.plus(REMINDER_WINDOW);
        int sentCount = 0;

        for (Event event : eventDao.getEventsWithoutReminder(userId)) {
            LocalDateTime start = event.getStartDateTime();
            boolean isUpcoming = start != null && start.isAfter(now) && !start.isAfter(cutoff);
            if (isUpcoming && sendText(context, phoneNumber, buildMessage(context, event))) {
                eventDao.markReminderSent(event.getId()); // Only text once per event.
                sentCount++;
            }
        }
        return sentCount;
    }

    private static String buildMessage(Context context, Event event) {
        return context.getString(R.string.sms_reminder_message,
                event.getName(), event.getDate(), event.getTime());
    }

    /** Sends one text. Returns false instead of crashing if sending fails. */
    private static boolean sendText(Context context, String phoneNumber, String message) {
        try {
            getSmsManager(context).sendTextMessage(phoneNumber, null, message, null, null);
            return true;
        } catch (RuntimeException e) {
            Log.w(TAG, "Could not send SMS reminder", e);
            return false;
        }
    }

    /** Android 12 (API 31) changed how SmsManager is obtained, so handle both cases. */
    @SuppressWarnings("deprecation")
    private static SmsManager getSmsManager(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return context.getSystemService(SmsManager.class);
        }
        return SmsManager.getDefault();
    }
}
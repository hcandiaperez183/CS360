package com.example.eventtracker;

import android.widget.EditText;

/** Small helpers shared by the screens that read form fields. */
public final class FormUtils {

    private FormUtils() {
        // Utility class: no instances.
    }

    /** Returns the field's text with spaces trimmed, never null. */
    public static String textOf(EditText field) {
        return field.getText() == null ? "" : field.getText().toString().trim();
    }
}
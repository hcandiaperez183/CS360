package com.example.eventtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Create, read, update, and delete for the events table. */
public class EventDao {

    private final DatabaseHelper dbHelper;

    public EventDao(Context context) {
        dbHelper = DatabaseHelper.getInstance(context);
    }

    /** CREATE: adds a new event for this user and returns its ID. */
    public long addEvent(long userId, Event event) {
        ContentValues values = toContentValues(event);
        values.put(DatabaseHelper.COL_EVENT_USER_ID, userId);
        return dbHelper.getWritableDatabase().insert(DatabaseHelper.TABLE_EVENTS, null, values);
    }

    /** READ: all of this user's events, soonest first (unreadable dates go last). */
    public List<Event> getEventsForUser(long userId) {
        List<Event> events = queryEvents(DatabaseHelper.COL_EVENT_USER_ID + " = ?",
                new String[]{String.valueOf(userId)});
        events.sort(Comparator.comparing(Event::getStartDateTime,
                Comparator.nullsLast(Comparator.naturalOrder())));
        return events;
    }

    /** READ: one event by ID, or null if it no longer exists. */
    public Event getEvent(long eventId) {
        List<Event> matches = queryEvents(DatabaseHelper.COL_EVENT_ID + " = ?",
                new String[]{String.valueOf(eventId)});
        return matches.isEmpty() ? null : matches.get(0);
    }

    /** READ: this user's events that haven't had an SMS reminder yet. */
    public List<Event> getEventsWithoutReminder(long userId) {
        return queryEvents(DatabaseHelper.COL_EVENT_USER_ID + " = ? AND "
                        + DatabaseHelper.COL_REMINDER_SENT + " = 0",
                new String[]{String.valueOf(userId)});
    }

    /** UPDATE: saves new values for an existing event. */
    public void updateEvent(Event event) {
        ContentValues values = toContentValues(event);
        // The date or time may have changed, so allow a new reminder to be sent.
        values.put(DatabaseHelper.COL_REMINDER_SENT, 0);
        dbHelper.getWritableDatabase().update(DatabaseHelper.TABLE_EVENTS, values,
                DatabaseHelper.COL_EVENT_ID + " = ?", new String[]{String.valueOf(event.getId())});
    }

    /** UPDATE: records that the SMS reminder for this event went out. */
    public void markReminderSent(long eventId) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COL_REMINDER_SENT, 1);
        dbHelper.getWritableDatabase().update(DatabaseHelper.TABLE_EVENTS, values,
                DatabaseHelper.COL_EVENT_ID + " = ?", new String[]{String.valueOf(eventId)});
    }

    /** DELETE: removes an event permanently. */
    public void deleteEvent(long eventId) {
        dbHelper.getWritableDatabase().delete(DatabaseHelper.TABLE_EVENTS,
                DatabaseHelper.COL_EVENT_ID + " = ?", new String[]{String.valueOf(eventId)});
    }

    /** Runs a query on the events table and turns each row into an Event. */
    private List<Event> queryEvents(String selection, String[] selectionArgs) {
        List<Event> events = new ArrayList<>();
        try (Cursor cursor = dbHelper.getReadableDatabase().query(DatabaseHelper.TABLE_EVENTS,
                null, selection, selectionArgs, null, null, DatabaseHelper.COL_EVENT_ID)) {
            while (cursor.moveToNext()) {
                events.add(readEvent(cursor));
            }
        }
        return events;
    }

    /** Builds an Event from the cursor's current row. */
    private static Event readEvent(Cursor cursor) {
        return new Event(
                cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_ID)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_NAME)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_DATE)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_TIME)),
                cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_EVENT_DESCRIPTION)));
    }

    /** The columns the user can edit, packed for an insert or update. */
    private static ContentValues toContentValues(Event event) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COL_EVENT_NAME, event.getName());
        values.put(DatabaseHelper.COL_EVENT_DATE, event.getDate());
        values.put(DatabaseHelper.COL_EVENT_TIME, event.getTime());
        values.put(DatabaseHelper.COL_EVENT_DESCRIPTION, event.getDescription());
        return values;
    }
}
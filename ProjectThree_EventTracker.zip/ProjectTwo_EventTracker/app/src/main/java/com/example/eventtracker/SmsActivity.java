package com.example.eventtracker;

import android.Manifest;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

/**
 * SMS reminders screen. Saves the user's phone number, asks for the
 * SEND_SMS permission, and shows the result. If the user says no, the
 * rest of the app keeps working; it just doesn't send reminders.
 */
public class SmsActivity extends AppCompatActivity {

    private TextView statusText;
    private EditText phoneField;
    private UserDao userDao;
    private long userId;

    // Shows the system permission dialog and receives the user's answer.
    private final ActivityResultLauncher<String> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                    this::onPermissionResult);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        statusText = findViewById(R.id.textSmsStatus);
        phoneField = findViewById(R.id.editPhoneNumber);
        userDao = new UserDao(this);
        userId = getIntent().getLongExtra(LoginActivity.EXTRA_USER_ID, UserDao.NO_USER);

        // Show the saved number and the current status if the user set this up before.
        phoneField.setText(userDao.getPhoneNumber(userId));
        if (SmsReminderSender.hasSmsPermission(this)) {
            statusText.setText(R.string.sms_status_granted);
        }

        findViewById(R.id.buttonEnableSms).setOnClickListener(v -> enableReminders());
        findViewById(R.id.buttonBackToEvents).setOnClickListener(v -> finish());
    }

    /** Saves the phone number, then asks for permission if the app doesn't have it yet. */
    private void enableReminders() {
        String phoneNumber = FormUtils.textOf(phoneField);
        if (!Patterns.PHONE.matcher(phoneNumber).matches()) {
            phoneField.setError(getString(R.string.error_phone_invalid));
            return;
        }
        userDao.setPhoneNumber(userId, phoneNumber);

        if (SmsReminderSender.hasSmsPermission(this)) {
            onPermissionResult(true);
        } else {
            permissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    /** Updates the status message and, if allowed, sends any reminders already due. */
    private void onPermissionResult(Boolean granted) {
        if (!Boolean.TRUE.equals(granted)) {
            statusText.setText(R.string.sms_status_denied);
            return;
        }
        statusText.setText(R.string.sms_status_granted);
        int remindersSent = SmsReminderSender.sendDueReminders(this, userId);
        if (remindersSent > 0) {
            Toast.makeText(this, getString(R.string.reminders_sent, remindersSent),
                    Toast.LENGTH_SHORT).show();
        }
    }
}
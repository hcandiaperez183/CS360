package com.example.eventtracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/** Reads and writes rows in the users table. */
public class UserDao {

    /** Returned when no matching user exists (or a new one couldn't be created). */
    public static final long NO_USER = -1;

    private final DatabaseHelper dbHelper;

    public UserDao(Context context) {
        dbHelper = DatabaseHelper.getInstance(context);
    }

    /**
     * Creates a new account and returns its ID.
     * Returns NO_USER if the username is already taken (the UNIQUE rule blocks the insert).
     */
    public long createUser(String username, String password) {
        String salt = PasswordHasher.newSalt();
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COL_USERNAME, username);
        values.put(DatabaseHelper.COL_SALT, salt);
        values.put(DatabaseHelper.COL_PASSWORD_HASH, PasswordHasher.hash(password, salt));
        return dbHelper.getWritableDatabase().insert(DatabaseHelper.TABLE_USERS, null, values);
    }

    /** Returns the user's ID if the username and password match, otherwise NO_USER. */
    public long checkLogin(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {DatabaseHelper.COL_USER_ID,
                DatabaseHelper.COL_PASSWORD_HASH, DatabaseHelper.COL_SALT};

        try (Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, columns,
                DatabaseHelper.COL_USERNAME + " = ?", new String[]{username},
                null, null, null)) {
            if (!cursor.moveToFirst()) {
                return NO_USER; // No account with that username.
            }
            String salt = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_SALT));
            String storedHash = cursor.getString(
                    cursor.getColumnIndexOrThrow(DatabaseHelper.COL_PASSWORD_HASH));
            long userId = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_USER_ID));
            return PasswordHasher.matches(password, salt, storedHash) ? userId : NO_USER;
        }
    }

    /** Returns the user's saved phone number, or null if they haven't entered one. */
    public String getPhoneNumber(long userId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        try (Cursor cursor = db.query(DatabaseHelper.TABLE_USERS,
                new String[]{DatabaseHelper.COL_PHONE},
                DatabaseHelper.COL_USER_ID + " = ?", new String[]{String.valueOf(userId)},
                null, null, null)) {
            return cursor.moveToFirst() ? cursor.getString(0) : null;
        }
    }

    /** Saves the phone number that SMS reminders are sent to. */
    public void setPhoneNumber(long userId, String phoneNumber) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COL_PHONE, phoneNumber);
        dbHelper.getWritableDatabase().update(DatabaseHelper.TABLE_USERS, values,
                DatabaseHelper.COL_USER_ID + " = ?", new String[]{String.valueOf(userId)});
    }
}
package com.example.eventtracker;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/** Fills the event grid: one item_event.xml row per event. */
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    /** Lets the screen handle edit and delete taps (the screen owns the database). */
    public interface OnEventActionListener {
        void onEditEvent(Event event);

        void onDeleteEvent(Event event);
    }

    private final List<Event> events = new ArrayList<>();
    private final OnEventActionListener actionListener;

    public EventAdapter(OnEventActionListener actionListener) {
        this.actionListener = actionListener;
    }

    /** Replaces every row with a fresh list loaded from the database. */
    @SuppressLint("NotifyDataSetChanged")
    public void setEvents(List<Event> newEvents) {
        events.clear();
        events.addAll(newEvents);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_event, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = events.get(position);
        holder.nameText.setText(event.getName());
        holder.dateText.setText(event.getDate());
        holder.timeText.setText(event.getTime());

        // Tapping the row or the edit button opens the event for editing.
        holder.row.setOnClickListener(v -> actionListener.onEditEvent(event));
        holder.editButton.setOnClickListener(v -> actionListener.onEditEvent(event));
        holder.deleteButton.setOnClickListener(v -> actionListener.onDeleteEvent(event));
    }

    @Override
    public int getItemCount() {
        return events.size();
    }

    /** Holds the views for one row so they aren't looked up again on every scroll. */
    static class EventViewHolder extends RecyclerView.ViewHolder {
        final View row;
        final TextView nameText;
        final TextView dateText;
        final TextView timeText;
        final ImageButton editButton;
        final ImageButton deleteButton;

        EventViewHolder(@NonNull View itemView) {
            super(itemView);
            row = itemView.findViewById(R.id.rowEvent);
            nameText = itemView.findViewById(R.id.textEventName);
            dateText = itemView.findViewById(R.id.textEventDate);
            timeText = itemView.findViewById(R.id.textEventTime);
            editButton = itemView.findViewById(R.id.buttonEditEvent);
            deleteButton = itemView.findViewById(R.id.buttonDeleteEvent);
        }
    }
}